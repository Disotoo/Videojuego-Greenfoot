import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Bravo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bravo extends Animal
{
    /**
     * Act - do whatever the Bravo wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        move(3);
        
        if( Greenfoot.getRandomNumber(100) < 10 )
        {
            turn(Greenfoot.getRandomNumber(60)-30);
        }
        
        if (atWorldEdge())
        {
            turn(Greenfoot.getRandomNumber(30));
        }      
            
        if (canSee(Perrito.class))
        {
            eat(Perrito.class);
            Greenfoot.playSound("Bra.wav");
        }
    }   
}
