import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Casa2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Casa2 extends Animal
{
    /**
     * Act - do whatever the Casa2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        if (isTouching(Perrito.class))
        {
            removeTouching(Perrito.class);
            Counter counter = (Counter) getWorld().getObjects(Counter.class).get(0);
            counter.add(50);
            Greenfoot.playSound("ee.mp3");
            Greenfoot.setWorld(new Finish());
        }

    }
}
