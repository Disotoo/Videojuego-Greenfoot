import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Level1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Level1 extends World
{
    /**
     * Constructor for objects of class Level1.
     * 
     */
    public Level1()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {

        Comida comida = new Comida();
        addObject(comida,45,35);
        Bravo bravo = new Bravo();
        addObject(bravo,128,108);
        Perrito perrito = new Perrito();
        addObject(perrito,558,356);
        Pincho pincho = new Pincho();
        addObject(pincho,362,108);
        Pincho pincho2 = new Pincho();
        addObject(pincho2,163,257);
        Pincho pincho3 = new Pincho();
        addObject(pincho3,386,277);
        Counter counter = new Counter();
        addObject(counter,534,32);
        Casa casa = new Casa();
        addObject(casa,554,257);
        removeObject(perrito);
        casa.setLocation(565,345);
        casa.setLocation(565,354);
        Perrito perrito2 = new Perrito();

        g g = new g();

        casa.setLocation(51,353);
        addObject(perrito2,554,364);
        casa.setLocation(58,347);
        addObject(g,58,347);
        casa.setLocation(80,338);
        casa.setLocation(122,313);
        casa.setLocation(24,375);
        pincho2.setLocation(82,338);
        pincho2.setLocation(92,404);
        pincho2.setLocation(65,241);
        pincho2.setLocation(226,221);
        g.setLocation(92,339);
        g.setLocation(55,342);
        
        GreenfootSound sound = new GreenfootSound("music2.mp3");
        sound.play();
    } 
}
