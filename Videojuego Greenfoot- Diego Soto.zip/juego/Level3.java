import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Level3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Level3 extends World
{

    /**
     * Constructor for objects of class Level3.
     * 
     */
    public Level3()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Counter counter = new Counter();
        addObject(counter,539,25);
        Comida comida = new Comida();
        addObject(comida,43,34);
        counter.setLocation(51,384);
        counter.setLocation(544,28);
        g g = new g();
        addObject(g,51,348);
        counter.setLocation(558,378);
        comida.setLocation(560,40);
        Perrito perrito = new Perrito();
        addObject(perrito,45,45);
        Bravo bravo = new Bravo();
        addObject(bravo,409,62);
        Bravo bravo2 = new Bravo();
        addObject(bravo2,507,173);
        Pincho pincho = new Pincho();
        addObject(pincho,264,34);
        Pincho pincho2 = new Pincho();
        addObject(pincho2,262,103);
        Pincho pincho3 = new Pincho();
        addObject(pincho3,376,376);
        Pincho pincho4 = new Pincho();
        addObject(pincho4,375,312);
        Pincho pincho5 = new Pincho();
        addObject(pincho5,113,284);
        Pincho pincho6 = new Pincho();
        addObject(pincho6,164,241);
        counter.setLocation(539,375);
        g.setLocation(49,351);
        g.setLocation(55,350);
        Casa2 casa2 = new Casa2();
        addObject(casa2,31,363);
    }
}
