import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Level2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Level2 extends World
{

    /**
     * Constructor for objects of class Level2.
     * 
     */
    public Level2()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Comida comida = new Comida();
        addObject(comida,556,366);
        g g = new g();
        addObject(g,51,350);
        Pincho pincho = new Pincho();
        addObject(pincho,129,175);
        Pincho pincho2 = new Pincho();
        addObject(pincho2,237,88);
        Pincho pincho3 = new Pincho();
        addObject(pincho3,167,311);
        Pincho pincho4 = new Pincho();
        addObject(pincho4,291,220);
        Pincho pincho5 = new Pincho();
        addObject(pincho5,410,122);
        Pincho pincho6 = new Pincho();
        addObject(pincho6,401,294);
        pincho2.setLocation(261,75);
        pincho.setLocation(155,163);
        pincho3.setLocation(184,275);
        pincho4.setLocation(313,200);
        pincho5.setLocation(443,63);
        pincho4.setLocation(322,179);
        pincho3.setLocation(218,285);
        pincho6.setLocation(408,290);
        Bravo bravo = new Bravo();
        addObject(bravo,486,243);
        Perrito perrito = new Perrito();
        addObject(perrito,37,48);
        Counter counter = new Counter();
        addObject(counter,536,22);
        removeObject(pincho3);
        pincho4.setLocation(222,308);
        pincho5.setLocation(367,177);
        pincho5.setLocation(313,221);
        pincho6.setLocation(441,100);
        pincho.setLocation(158,114);
        pincho4.setLocation(375,320);
        pincho5.setLocation(192,257);
        pincho2.setLocation(326,137);
        pincho5.setLocation(209,251);
        pincho4.setLocation(327,304);
        pincho6.setLocation(464,74);
        pincho4.setLocation(313,325);
        addObject(pincho3,431,235);
        pincho5.setLocation(153,249);
        pincho2.setLocation(304,68);
        pincho3.setLocation(310,196);
        pincho6.setLocation(458,179);
        pincho6.setLocation(436,124);
        pincho4.setLocation(427,289);
        pincho5.setLocation(210,305);
        pincho.setLocation(177,160);
        g.setLocation(52,347);
        Casa1 casa1 = new Casa1();
        addObject(casa1,34,361);
    }
}
